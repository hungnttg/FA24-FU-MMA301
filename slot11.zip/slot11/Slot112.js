import React,{useState} from "react";
import { View,Text,TextInput,Button,StyleSheet } from "react-native";
//header component
const Header = ({title})=>{
    return(
        <View style={styles.header}>
        <Text style={styles.headerText}>{title}</Text>
        </View>
    );
    
};
//footer component
const Footer=({info})=>{
    return(
        <View style={styles.footer}>
            <Text style={styles.footerText}>{info}</Text>
        </View>
    );
    
};
const App = ()=>{
    //code
    const [inputValue,setInputValue]=useState('');
    const [footerInfo,setFooterInfo]=useState('');
    const handleSubmit=()=>{
        setFooterInfo(inputValue);
        setInputValue('');
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Header title="my app"/>
            <View style={styles.main}>
                <TextInput
                    style={styles.input}
                    placeholder="Enter string"
                    value={inputValue}
                    onChangeText={setInputValue}
                />
                <Button title="Submit" onPress={handleSubmit}/>
            </View>
            <Footer info={footerInfo}/>
            
        </View>
    );
};
const styles=StyleSheet.create({
    container:{
        flex:1,
        //dat khoang cach giua cac phan
        justifyContent:'space-between',
        backgroundColor:'#fff',
    },
    header:{
        backgroundColor:'lightblue',
        padding:10,
    },
    headerText:{
        fontSize:20,
        fontWeight:'bold',
        textAlign:'center',
    },
    main:{
        flex:1,
        justifyContent:'center',
        marginVertical:20,
    },
    footer:{
        backgroundColor:'lightblue',
        padding:10,
    },
    footerText:{
        fontSize:30,
        fontWeight:'bold',
    },
    input:{
        height:40,
        borderBlockColor:'#111',
        borderWidth:1,
        marginBottom:10,
        marginLeft:10,
    },
});
export default App;