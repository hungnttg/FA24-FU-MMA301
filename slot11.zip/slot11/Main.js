import React,{useState} from "react";
import { View,StyleSheet } from "react-native";
import Header from "./Header";
import Footer from "./Footer";
import Body from "./Body";
const Main=()=>{
    //code
    const [footerInfo,setFooterInfo]=useState('');
    handleSubmit=(inputValue)=>{
        setFooterInfo(inputValue);
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Header/>
            <Body onSubmit={handleSubmit} />
            <Footer info={footerInfo}/>
        </View>
    );
}
const styles=StyleSheet.create({
    container:{
        flex:1,
    },
});
export default Main;