import React,{useState} from "react";
import { Text,View,StyleSheet,Button,TextInput } from "react-native";
const Body=({onSubmit})=>{
    //code
    const [inputValue,setInputValue]=useState('');
    const handleSubmit = () =>{
        onSubmit(inputValue);
        setInputValue('');
    };

    //giao dien
    return(
        <View style={styles.body}>
            <TextInput
                style={styles.input}
                placeholder="nhap du lieu"
                value={inputValue}
                onChangeText={setInputValue}
            />
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );
}
const styles=StyleSheet.create({
    body:{
        padding: 10,
    },
    input:{
        height:40,
        borderBlockColor:'#111',
        borderWidth:1,
        marginBottom:10,
        marginLeft:10,
    },
});
export default Body;