import React from "react";
import { Text,View,StyleSheet } from "react-native";
const Footer=({info})=>{
    return(
        <View style={styles.footer}>
            <Text style={styles.footerText}>{info}</Text>
        </View>
    );
}
const styles=StyleSheet.create({
    footer:{
        backgroundColor:'#aaa555',
        padding:10,
    },
    footerText:{
        fontSize:30,
        fontWeight:'bold',
    },
});
export default Footer;