import React,{useState} from "react";
import { Text,View,TextInput,StyleSheet,Button } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
//tao tab navigator
const Tab = createBottomTabNavigator();
//header component
const Header=({title})=>{
    
        <View style={styles.header}>
            <Text style={styles.headerText}>{title}</Text>
        </View>
    
};
//body component
const MainScreen = ()=>{
    const [inputValue,setInputValue]=useState('');
    const [footerInfo,setFooterInfo]=useState('');
    const handleSubmit=()=>{
        setFooterInfo(inputValue);
        setInputValue('');
    };
    return(
        <View style={styles.main}>
            <TextInput 
                style={styles.input}
                placeholder="Nhap lieu"
                value={inputValue}
                onChangeText={setInputValue}
            />
            <Button title="Submit" onPress={handleSubmit} />
            <Text style={styles.footerText}>{footerInfo}</Text>
        </View>
    );
};
//them trang moi
const InfoScreen=()=>{
    
        <View style={styles.main}>
            <Text>Welcome to the Info Screen</Text>
        </View>
      
};
const App=()=>{
    return(
        <NavigationContainer>
            <Tab.Navigator>
                <Tab.Screen name="Home">
                    {()=>(
                        <>
                            <Header title="My App"/>
                            <MainScreen />
                        </>
                    )}
                </Tab.Screen>
                <Tab.Screen name="Info" component={InfoScreen}/>
            </Tab.Navigator>
        </NavigationContainer>
    );
};
const styles=StyleSheet.create({
    
    header:{
        backgroundColor:'lightblue',
        padding:10,
    },
    headerText:{
        fontSize:20,
        fontWeight:'bold',
        textAlign:'center',
    },
    main:{
        flex:1,
        justifyContent:'center',
        marginVertical:20,
    },
    footer:{
        backgroundColor:'lightblue',
        padding:10,
    },
    footerText:{
        fontSize:30,
        fontWeight:'bold',
    },
    input:{
        height:40,
        borderBlockColor:'#111',
        borderWidth:1,
        marginBottom:10,
        marginLeft:10,
    },
});
export default App;
//npm install @react-native-community/masked-view
//npm install react-native-safe-area-context
//npm install react-native-screens
//npm install react-native-reanimated 
//npm install react-native-gesture-handler
//npm install @react-navigation/bottom-tabs
//npm install @react-navigation/native 