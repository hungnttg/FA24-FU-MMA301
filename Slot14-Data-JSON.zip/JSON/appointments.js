[
    {
      "customerId": "1",
      "date": "2024-10-10",
      "time": "10:00",
      "status": "confirmed"
    },
    {
      "customerId": "2",
      "date": "2024-10-15",
      "time": "14:00",
      "status": "pending"
    }
  ]