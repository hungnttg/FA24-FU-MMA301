import React from "react";
import { Text,View,StyleSheet, Image } from "react-native";
const SectionView=({title,imageSource,description})=>{
    return(
        <View style={styles.container}>
            <Text style={styles.title} >{title}</Text>
            <Image source={imageSource} style={styles.image}/>
            <Text style={styles.description}>{description}</Text>
        </View>
    );
}
const Slot102=()=>{
    return(
        <View style={styles.container}>
            <SectionView
                title="Xin chao"
                imageSource={{uri:'https://daihoc.fpt.edu.vn/wp-content/uploads/2023/04/cropped-cropped-2021-FPTU-Long.png'}}
                description="day la mo ta"
            />
        </View>
    );
    
}
const styles=StyleSheet.create({
    container:{
        padding:20,
        backgroundColor: '#ffffff',
        borderRadius: 10,
        shadowColor: '#000',

    },
    title:{
        fontSize:25,
        fontWeight:'bold',
        marginBottom:20,
    },
    image:{
        width: 100,
        height:50,
        marginBottom:10,
        borderRadius:5,
    },
    description:{
        fontSize:18,
    },

});
export default Slot102;