import React from "react";
import { Text,View,StyleSheet } from "react-native";
const SectionView=({title,children,backgroundColor})=>{
    return(
        <View style={[styles.container,{backgroundColor}]}>
            <Text style={styles.title}>{title}</Text>
            {children}
        </View>
    );
}
const Slot101 = ()=>{
    return(
        <View style={styles.container}>
            <SectionView title="Header" backgroundColor="#ccc">
                <Text>Header</Text>
            </SectionView>
            <SectionView title="Content" backgroundColor="#eee">
                <Text>Content</Text>
            </SectionView>
            <SectionView title="Footer" backgroundColor="#ababab">
                <Text>Footer</Text>
            </SectionView>
        </View>
    );
}
const styles=StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    title:{
        fontSize:20,
        fontWeight:'bold',
        marginBottom:20,
    },

});
export default Slot101;