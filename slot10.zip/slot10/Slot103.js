import React,{useState} from "react";
import { Text,TextInput,Button,StyleSheet, View } from "react-native";
const Slot103=()=>{
    const [inputValue,setInputValue]=useState('');
    const [isInputValid,setIsInputValid]=useState(true);
    const handleBlur=()=>{
        setIsInputValid(inputValue.trim()!=='');
    };
    const handleSubmit=()=>{
        setIsInputValid(inputValue.trim()!=='');
    };
    return(
        <View style={styles.container}>
            <TextInput style={[styles.input, styles.invalid]}
                placeholder="nhap du lieu"
                onChangeText={text=>{
                    setInputValue(text);
                    setIsInputValid(true);
                }}
                onBlur={handleBlur}
            />
            {
                !isInputValid && <Text style={styles.errorText}>Vui long khong de trong</Text>
            }
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );

}
const styles=StyleSheet.create({
    container:{
       flex:1,
       justifyContent:'center',
       alignItems:'center',
    },
    input:{
        borderWidth:1,
        borderColor:'#ccc',
        padding:20,
        marginBottom:20,
        width:'80%',
    },
    invalid:{
        borderColor:'red',
    },
    errorText:{
        color:'red',
        marginBottom:10,
    },
});
export default Slot103;