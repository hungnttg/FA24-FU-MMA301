const express = require('express');
const mysql=require('mysql2');
const cors=require('cors');

const app=express();
app.use(cors());
const connection = mysql.createConnection({
    host:'localhost',user:'root',password:'',database:'a5'
});
app.get('/api/products',(req,res)=>{
    connection.query('SELECT * from mytable',(err,results)=>{
        if(err) return res.status(500).send('loi database');
        res.json({products: results});
    });
});
app.listen(3000,()=>console.log('server dang chay o cong 3000'));