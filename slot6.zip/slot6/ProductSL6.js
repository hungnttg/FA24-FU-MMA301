import React from "react";
import { Text,View,Image,StyleSheet,TouchableWithoutFeedback } from "react-native";
//dinh nghia model
const ProductSL6 = (props) =>{
    //code
    const {
        dataProd={},

    }=props;
    //giao dien
    return(
        <View style={styles.container}>
            <TouchableWithoutFeedback>
                <View>
                    <Image source={{uri:dataProd.search_image}} style={styles.image}/>
                    <Text>{dataProd.styleid}</Text>
                    <Text>{dataProd.brands_filter_facet}</Text>
                    <Text>{dataProd.price}</Text>
                    <Text>{dataProd.product_additional_info}</Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    );
}
export default ProductSL6;
const styles=StyleSheet.create({
    container:{
      flex:1,  
    },
    image:{
        width:200,
        height:200,
        borderWidth:1,
    },
});