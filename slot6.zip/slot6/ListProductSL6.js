//import thu vien
import React from "react";
import { FlatList } from "react-native";
import ProductSL6 from "./ProductSL6";
export default class ListProductSL6 extends React.Component{
    //code
    constructor(props){
        super(props);
        this.state={
            products: null,
        };
        //khoi tao
        this.getProducts=this.getProducts.bind(this);
        this.renderItem=this.renderItem.bind(this);
    }
    //khi goi component thi se goi ham nay
    componentDidMount(){
        this.getProducts();
    }
    //dinh nghia ham: get data
    async getProducts(){
        const url='http://10.22.10.72/MMA301/index.php';
        let response =await fetch(url,{method:'GET'});
        let responseJSON = await response.json();
        //cap nhat vao state
        this.setState({
            products: responseJSON.products,
        });
    }
    //ham ket xuat du lieu
    renderItem({item}){
        return(
            <ProductSL6
                dataProd={item}
            />
        );
    }
    //design
    render(){
        return(
            <FlatList
                data={this.state.products}
                renderItem={this.renderItem}
                numColumns={3}
                removeClippedSubviews
            />
        );
    }

}