import React,{useState,useEffect} from "react";
import { Text,View,Button,TextInput,StyleSheet } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { loginUser } from "../services/api";
const LoginScr = ({navigation})=>{
    const [username,setUsername]=useState('');
    const [password,setPassword]=useState('');
    const [error,setError] = useState('');
    //keiem tra dang nhap
    useEffect(()=>{
        const checkLoginStatus = async () =>{
            const userData = await AsyncStorage.getItem('userData');
            if(userData){
                const parsedData = JSON.parse(userData);
                //neu da co thong tin dang nhap thi ta chuyen den home
                navigation.navigate('DressesScr',{role:parsedData.role});
            }
        };
        checkLoginStatus();
    },[]);
    const handleLogin = async () =>{
        try {
            const response = await loginUser(username,password);
            if(response.role){
                //luu thong tin
                await AsyncStorage.setItem('userData',JSON.stringify({
                    username:username,
                    role:response.role
                }));
                //dieu huong den trang home
                navigation.navigate('DressesScr',{role:response.role});
            }
            

        } catch (error) {
            setError(error.message);
            console.error("Login that bai: ",error);
        }
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Text style={styles.label}>Username: </Text>
            <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="Nhap username"
            />
            <Text style={styles.label}>Password: </Text>
            <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="Nhap password"
                secureTextEntry
            />
            {error? <Text style={styles.error}>{error}</Text> : null}
            <Button title="Login" onPress={handleLogin}/>
        </View>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    label: {
        fontSize:16,
        marginBottom:10,
    },
    input:{
        borderWidth:1,
        borderColor:'#bbb',
        padding:10,
        borderRadius:10,
        marginBottom:10,
    },
    error:{
        color:'red',
        marginBottom:10,
    }
});
export default LoginScr;