import axios from "axios";
import React, { useEffect, useState } from "react";
import { Text,View,TextInput,Button,StyleSheet,FlatList, Alert } from "react-native";
const DressesScr = () =>{
    const [dresses, setDresses] = useState([]);
    const [name,setName] = useState('');
    const [description, setDescription]=useState('');
    const [selectedDressId,setSelectedDressId]=useState(null);
    useEffect(()=>{
        fetchDresses();
    },[]);
    const fetchDresses = async () =>{
        try {
            const response = await axios.get('http://localhost:5001/api/dresses');
            setDresses(response.data);
        } catch (error) {
            console.error(error);
        }
    };
    const handleAddOrUpdateDress = async () =>{
        if(name==''|| description==''){
            Alert.alert('Error','Khong duoc de trong');
            return;
        }
        try {
            if(selectedDressId){
                //sua ao cuoi
                await axios.put(`http://localhost:5001/api/dresses/${selectedDressId}`,{
                    name,description
                });
                Alert.alert('Thanh cong','Sua vay thanh cong');
            }
            else {
                //them moi ao cuoi
                await axios.post('http://localhost:5001/api/dresses',{
                    name,description
                });
                Alert.alert('Thanh cong','Them vay thanh cong');
            }
            setName('');
            setDescription('');
            setSelectedDressId(null);//reset form
            fetchDresses();//cap nhat lai danh sach
        } catch (error) {
            console.log(error);
            Alert.alert('Error',error);
        }
    };
    const handleEditDress = (dress) =>{
        setName(dress.name);
        setDescription(dress.description);
        setSelectedDressId(dress.id);//dat id de biet dang chinh sua
    };
    const handleDeleteDress = async (_id) =>{
        try {
            await axios.delete(`http://localhost:5001/api/dresses/${_id}`);
            Alert.alert('Delete','Xoa thanh cong');
            fetchDresses();//cap nhat lai danh sach
        } catch (error) {
            console.log(error);
            Alert.alert('Error',error);
        }
    };
    const handleUpdateDress = async (id) =>{
        try {
            const response = await axios.put(`http://localhost:5001/api/dresses/${id}`,{
                name,description
            });
            //kiem tra phan hoi tu server
            if(response.status==200){
                Alert.alert('Thong bao','update thanh cong')
            }
        } catch (error) {
            console.log(error);
            Alert.alert('Thong bao',error);
        }
    };
    //giao dien
    return(
        <View style={styles.container}>
            <Text style={styles.title}>Quan ly Ao cuoi</Text>
            {/* them form sua ao cuoi */}
            <TextInput
                style={styles.input}
                placeholder="Dress name"
                value={name}
                onChangeText={setName}
            />
             <TextInput
                style={styles.input}
                placeholder="Dress Description"
                value={description}
                onChangeText={setDescription}
            />
            <Button title={selectedDressId ? "Update Dress": "Add Dress"}
            onPress={handleAddOrUpdateDress}/>
            {/* danh sach ao cuoi */}
            <FlatList data={dresses} 
                keyExtractor={(item)=>item._id.toString()}
                renderItem={({item})=>(
                    <View style={styles.dressItem}>
                        <Text style={styles.dressText}>{item._id}</Text>
                        <Text style={styles.dressText}>{item.name}: {item.description}</Text>
                        <Button title="Edit" onPress={()=>handleEditDress(item)}/>
                        <Button title="Delete" onPress={()=>handleDeleteDress(item._id)}/>
                        <Button title="Update" onPress={()=>handleUpdateDress(item._id)}/>   
                    </View>
                )}
            />
        </View>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    label: {
        fontSize:16,
        marginBottom:10,
    },
    input:{
        borderWidth:1,
        borderColor:'#bbb',
        padding:10,
        borderRadius:10,
        marginBottom:10,
    },
    error:{
        color:'red',
        marginBottom:10,
    },
    title:{
        fontSize:25,
        fontWeight:'bold',
    },
    dressItem:{
        padding:10,
        marginVertical:5,
        borderWidth:1,
    },
    dressText:{
        fontSize:16,
    },
});
export default DressesScr;