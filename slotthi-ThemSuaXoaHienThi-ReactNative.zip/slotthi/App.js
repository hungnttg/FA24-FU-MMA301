import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import LoginScreen from "./src/screens/LoginScreen";
import LoginScreen2 from "./src/screens/LoginScreen2";
import HomeScreen from "./src/screens/HomeScreen";
import DressDetailScreen from "./src/screens/DressDetailScreen";
import DatLichScreen from "./src/screens/DatLichScreen";
import DressesScreen from "./src/screens/DressesScreen";
import LoginScr from "./src/slotthi/LoginScr";
import DressesScr from "./src/slotthi/DressesScr";
 
const Stack = createStackNavigator();
const App = () =>{
    return(
        <NavigationContainer>
            <Stack.Navigator initialRouteName="LoginScr">
                <Stack.Screen name="LoginScr" component={LoginScr}/>
                <Stack.Screen name="DressesScr" component={DressesScr}/>

                <Stack.Screen name="Login" component={LoginScreen}/>
                <Stack.Screen name="Login2" component={LoginScreen2}/>
                <Stack.Screen name="Home" component={HomeScreen}/>
                <Stack.Screen name="DressDetail" component={DressDetailScreen}/>
                <Stack.Screen name="DatLich" component={DatLichScreen}/>
                <Stack.Screen name="DressesScreen" component={DressesScreen}/>
            </Stack.Navigator>
        </NavigationContainer>
    );
};
export default App;