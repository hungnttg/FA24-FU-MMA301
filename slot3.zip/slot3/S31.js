//import thu vien
import React from "react";
import { Button,Text,View,TouchableOpacity,StyleSheet } from "react-native";
//dinh nghia class
export default class S31 extends React.Component{
    //ham khoi tao
    constructor(){
        super();
        //khai bao hang
        this.operations=['DEL','+','-','*','/'];
        this.state={
            resultText:"",//bien luu ket qua
            calculationText:"",//bien luu bieu thuc tinh toan
        }
    }
    //cac ham tu dinh nghia
    //dinh nghia ham khi press button
    pressButton(text){
        if(text=="="){
            return this.calculationResult(this.state.resultText);
        }
        else if(text=="DEL"){
            this.operate('DEL');
        }
        else {
            this.setState({
                resultText: this.state.resultText + text, //noi them text
            });
        }
    }
    //ham tinh toan gia tri bieu thuc
    calculationResult(text){
        this.setState({
            calculationText: eval(text),//tinh gia tri bieu thuc
        });
    }
    //ham xu ly tinh toan
    operate(operation){
        switch(operation){
            case 'DEL':
                let text=this.state.resultText.split('');//pha vo chuoi
                text.pop();//xoa ky tu cuoi cung
                this.setState({
                    resultText: text.join(''),//join cac ky tu con lai thanh chuoi
                });
                break;
            case '+':
            case '-':
            case '*':
            case '/':
                this.setState({
                    resultText: this.state.resultText+operation,//noi phep tinh
                });
                break;
        }
    }
    // thiet ke giao dien
    render(){
        return(
            <View style={styles.container}>
            {/* hien thi ket qua */}
            <View style={styles.result}>
                <Text>{this.state.resultText}</Text>
            </View>
            {/* hien thi phan tinh toan */}
            <View style={styles.calculation}>
                <Text>{this.state.calculationText}</Text>
            </View>
            {/* hien thi phan button */}
            <View style={styles.buttons}>
                {/* cot 1 */}
                <View style={styles.number1}>
                    <TouchableOpacity style={styles.btn} key={1} onPress={()=>this.pressButton(1)}><Text>1</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={4} onPress={()=>this.pressButton(4)}><Text>4</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={7} onPress={()=>this.pressButton(7)}><Text>7</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'.'} onPress={()=>this.pressButton('.')}><Text>.</Text></TouchableOpacity>
                </View>
                {/* cot 2 */}
                <View style={styles.number2}>
                    <TouchableOpacity style={styles.btn} key={2} onPress={()=>this.pressButton(2)}><Text>2</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={5} onPress={()=>this.pressButton(5)}><Text>5</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={8} onPress={()=>this.pressButton(8)}><Text>8</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={0} onPress={()=>this.pressButton(0)}><Text>0</Text></TouchableOpacity>
                </View>
                {/* cot 3 */}
                <View style={styles.number3}>
                    <TouchableOpacity style={styles.btn} key={3} onPress={()=>this.pressButton(3)}><Text>3</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={6} onPress={()=>this.pressButton(6)}><Text>6</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={9} onPress={()=>this.pressButton(9)}><Text>9</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'='} onPress={()=>this.pressButton('=')}><Text>=</Text></TouchableOpacity>
                </View>
                {/* hien thi phep tinh */}
                <View style={styles.operations}>
                    <TouchableOpacity style={styles.btn} key={'+'} onPress={()=>this.pressButton('+')}><Text>+</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'-'} onPress={()=>this.pressButton('-')}><Text>-</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'*'} onPress={()=>this.pressButton('*')}><Text>*</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'/'} onPress={()=>this.pressButton('/')}><Text>/</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.btn} key={'DEL'} onPress={()=>this.pressButton('DEL')}><Text>DEL</Text></TouchableOpacity>
                </View>
            </View>
        </View>
        );
        
    }
}
const styles=StyleSheet.create({
    container:{
        flex:1,
        flexDirection:'column'
    },
    result:{
        flex:2,
        justifyContent:'space-around',
        alignItems:'flex-end',
        backgroundColor:'green'
    },
    calculation:{
        flex:1,
        justifyContent:'space-around',
        alignItems:'flex-end',
        backgroundColor:'#a1a1a1'
    },
    buttons:{
        flex:7,
        flexDirection:'row',
        backgroundColor:'#c2c2c2',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number1:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#d2d2d2',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number2:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#e2e2e2',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number3:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#f2f2f2',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    operations:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'yellow',
        justifyContent:'space-around',
        alignContent:'stretch',
    },
    btn:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    }
});