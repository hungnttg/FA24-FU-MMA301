import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";
const initialState={items:[]};
const cartReducer = createReducer(initialState,builder=>{
    builder.addCase(addItem,(state,action)=>{
        //lay ve id cua san pham
        const existingItemIndex = state.items.findIndex(item=>item.id===action.payload.id);
        if(existingItemIndex !== -1){//neu da ton tai id thi tang so luong len 1
            state.items[existingItemIndex].quantity++;
        }
        else {//neu chua ton tai id, thi them san pham vao gio hang voi so luong la 1
            state.items.push({...action.payload,quantity:1});
        }
    })
    .addCase(removeItem,(state,action)=>{
        //lay ve id cua san pham
        const existingItemIndex = state.items.findIndex(item=>item.id===action.payload.id);
        if(existingItemIndex !== -1){
            state.items[existingItemIndex].quantity--;//giam so luong
            //giam so luong den khi so luong san pham = 0 thi xoa san pham
            if(state.items[existingItemIndex].quantity===0){
                state.items.splice(existingItemIndex,1);//xoa san pham
            }
        }
    });
});
export default cartReducer;