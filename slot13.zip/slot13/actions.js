import { createAction } from "@reduxjs/toolkit";
export const addItem = createAction('cart/addItem');//them san pham vao gio hang
export const removeItem = createAction('cart/removeItem');//xoa san pham khoi gio hang
