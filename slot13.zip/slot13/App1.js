import React from "react";
import { View } from "react-native";
import { Provider } from "react-redux";
import store from "./Store"; 
import ProductList from "./ProductList";
import Cart from "./Cart";
 const products=[
    {id:1,name:'Product1'},
    {id:2,name:'Product2'},
    {id:3,name:'Product3'},
    {id:4,name:'Product4'},
 ];
 const App1=()=>{
    return(
        <Provider store={store}>
            <View>
                <ProductList products={products}/>
                <Cart/>
            </View>
        </Provider>
    );
 };
 export default App1;
